import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.Scanner;

/*CLASS THAT CONSTRUCTS AND EXTENDS THE JMENUBAR AND ALSO AN ACTIONLISTENER*/
public class win_menubar implements ActionListener {

    /*DECLARATION OF THE MENUBAR, MENU AND MENU ITEMS*/
    JMenuBar MenuBar;
    JMenu File;
    JMenu Edit;
    JMenu Run;
    JMenu Help;

    private workarea work; //calling the workarea class.

    /*File Menu Items*/
    JMenuItem New;
    JMenuItem Open;
    JMenuItem Save;
    JMenuItem SaveAs;
    JMenuItem Exit;

    /*Edit Menu Items*/
    JMenuItem Theme_white;
    JMenuItem Theme_black;

    /*Run Menu Items*/
    JMenuItem Runcode;
    JMenuItem O_CommandPrompt;
    JMenuItem CompilerDir;

    /*HELP ITEMS*/
    JMenuItem Github;
    JMenuItem Documentation;
    JMenuItem Contact;

    public win_menubar(){

        /*INITIALISING THE MENUS*/
        /*---------------------------------------------------------------------------------------------*/
       MenuBar = new JMenuBar();
       work = new workarea();

       File = new JMenu();
       Edit =  new JMenu();
       Run = new JMenu();
       Help = new JMenu();

       New = new JMenuItem("New");
       Open = new JMenuItem("Open");
       Save =  new JMenuItem("Save");
       SaveAs = new JMenuItem("Save As");
       Exit = new JMenuItem("Exit");

       Theme_black = new JMenuItem("Black Theme");
       Theme_white = new JMenuItem("White Theme");

       Runcode =  new JMenuItem("Run Code");
       O_CommandPrompt = new JMenuItem("Open CMD");
       CompilerDir = new JMenuItem("Compiler Dir");

       Github =  new JMenuItem("Github");
       Documentation =  new JMenuItem("Documentation");
       Contact =  new JMenuItem("Contact");
       /*----------------------------------------------------------------------------------------------------*/

       /*SETTING THE NAME OF THE JMENU AND ADDING OF ITS ITEMS*/
       File.setText("File");
       Edit.setText("Edit");
       Run.setText("Run");
       Help.setText("Help");

       /*-------------------------------------------------------------------------------------------------------*/
        /*ADDITION OF ITEMS*/
       /*FILE ITEMS*/
        File.add(New);
        File.add(Open);
        File.add(Save);
        File.add(SaveAs);
        File.add(Exit);

        /*EDIT ITEMS*/
        Edit.add(Theme_black);
        Edit.add(Theme_white);

        /*RUN ITEMS*/
        Run.add(Runcode);
        Run.add(O_CommandPrompt);
        Run.add(CompilerDir);

        /*HELP ITEMS*/
        Help.add(Github);
        Help.add(Documentation);
        Help.add(Contact);
        /*-------------------------------------------------------------------------------------------------------*/

        /*ITEM FUNCTIONALITIES*/
        Exit.addActionListener(this);
        SaveAs.addActionListener(this);
        Save.addActionListener(this);
        New.addActionListener(this);
        Open.addActionListener(this);

        Theme_black.addActionListener(this);
        Theme_white.addActionListener(this);

       /*ADDING THE JMENUS TO THE MENU BAR*/
       MenuBar.add(File);
       MenuBar.add(Edit);
       MenuBar.add(Run);
       MenuBar.add(Help);

    }

    /*BUTTON FUNCTIONALITIES*/
    @Override
    public void actionPerformed(ActionEvent e) {
        /*EXIT BUTTON LOGIC*/
        if (e.getSource()==Exit){
            System.exit(0);
        }
        /*OPEN BUTTON LOGIC*/
        if(e.getSource()==Open) {
            JFileChooser chooser = new JFileChooser();
            int result = chooser.showOpenDialog(null);
            chooser.setVisible(true);
            if (result==JFileChooser.APPROVE_OPTION){
                File file = new File(chooser.getSelectedFile().toString());
            try {
                work.getTexteditor().setText("");
                Scanner std = new Scanner(file);
                if (file.isFile()) {
                    while (std.hasNextLine()) {
                        String data = std.nextLine();
                        work.getTexteditor().append(data + "\n");
                    }
                }
                std.close();
            } catch (FileNotFoundException ex) {
                ex.printStackTrace();
            }
            }
        }
        /*SAVE AS BUTTON LOGIC*/
        if(e.getSource()==SaveAs){
            JFileChooser fileChooser=new JFileChooser();
            //fileChooser.setCurrentDirectory(new File("C:\\Users\\jonah\\Documents\\"));

            int resp = fileChooser.showSaveDialog(null);
            if(resp==JFileChooser.APPROVE_OPTION){
                File file;
                PrintWriter fileOut = null;

                file=new File(fileChooser.getSelectedFile().getAbsolutePath());
                try {
                    fileOut = new PrintWriter(file);
                    fileOut.println(work.getTexteditor().getText());
                }catch (FileNotFoundException e1){
                    e1.printStackTrace();
                }finally {
                    if (fileOut!=null){
                        fileOut.close();
                    }
                }
            }
        }
        /**********************************************************************************************************************************/
        /**************************THEME            CHANGE*********************************************************************************/
        if (e.getSource()==Theme_black){
            work.getInfoArea().setBackground(Color.BLACK);
        }
    }
}
